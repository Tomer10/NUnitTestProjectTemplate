﻿using System;
//using NUnit.Framework;

namespace $safeprojectname$
{
    //[TestFixture]
    public class NUnitTest1
    {
        //[Test]
        public void TestMethod1()
        {
        }
    }
}